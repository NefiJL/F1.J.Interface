package com.ifsc;

public interface Voador {

	public void voar();
}
