package com.ifsc;

public class PatoDeMadeira extends Duck {

	public PatoDeMadeira() {
	}

	public void display() {
		System.out.println("Oi, eu sou um pato de Madeira e n�o posso falar :(!");
	}

}
