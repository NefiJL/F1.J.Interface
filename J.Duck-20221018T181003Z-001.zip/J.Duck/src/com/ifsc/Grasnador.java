package com.ifsc;

public interface Grasnador {

	public void quack();

}
